#include "std_lib_facilities.h"

double randomWithLimits(int low, int high);
